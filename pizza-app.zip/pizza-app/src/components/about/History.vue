<template>
	<div class="history">
		<h4>历史订单</h4>
		<div class="con">
			<h3>历史订单</h3>
			<div>34654654756</div>
		</div>
	</div>
</template>

<script>
</script>

<style>
	
	.history{
		margin: 0 0 0 5%;
		border: 1px solid #F0F0F6;
		border-radius: 5px;		
	}
	h4{
		background: #EEEEF4;
	    margin: 0;
	    height: 40px;
	    line-height: 40px;	
	    padding: 0 10px;	
	}
	.con{
		padding: 0 0 20px 10px;
	}
</style>