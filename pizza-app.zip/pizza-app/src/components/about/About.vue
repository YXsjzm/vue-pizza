<template>
	<div class="about">
		<div>
			<el-row class="tac">
			  <el-col :span="4">
			    <el-menu default-active="2" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose">
			      <el-menu-item index="1">			      	
			      	<router-link tag="li" :to="{name:'historyLink'}" >
			      		历史订单
			      	</router-link>			        
			      </el-menu-item>
			      <el-menu-item index="2">
			      	<router-link tag="li" :to="{name:'contantLink'}">
			      		联系我们
			      	</router-link>			        
			      </el-menu-item>	
			      <el-menu-item index="3">
			      	<router-link tag="li" :to="{name:'orderGuideLink'}">
			      		点餐文档
			      	</router-link>			        
			      </el-menu-item>	
			      <el-menu-item index="4">
			      	<router-link tag="li" :to="{name:'shopingInforLink'}">
			      		快递信息
			      	</router-link>			       
			      </el-menu-item>
			    </el-menu>
			  </el-col>
			  
			  <el-col :span="20">
			    	<router-view  tag="div"></router-view>
			  </el-col>
			</el-row>			
		</div>
	</div>
</template>

<script>
</script>

<style>
	.about li{
		width: 100%;;		
	}
</style>