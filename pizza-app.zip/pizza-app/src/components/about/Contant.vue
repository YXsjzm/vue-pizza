<template>
	<div class="history">
		<h4>联系我们</h4>
		<div class="con">
			<h3>联系我们</h3>
			<div>34654654756</div>
			<div class="clearStyle"></div>
			<router-link tag="div" class="nav" to="/phone">
			       电话
			</router-link>
			<router-link tag="div" class="nav" to="/person">
				联系人
			</router-link>
			<div class="content">
				<router-view></router-view>
			</div>
			
		</div>
		
	</div>
</template>

<script>
	/*$(function () {  
	    alert(123);  
	 }); */
	export default({
		data: function () {
		    return { name: "herry" }
		},
		/*获取data的值使用vm*/
		/*beforeRouteEnter:(to,from,next)=>{	      
	      next(vm=>{
	      	alert("进入组件"+vm.name);
	      });
	    } ,
	    beforeRouteLeave:(to,from,next)=>{	      
	       if(confirm("确定要离开？")==true){
	       	 next()
	       }else{
	       	 next(false)
	       }
	    } ,*/
	})
</script>

<style>
	
	.history{
		margin: 0 0 0 5%;
		border: 1px solid #F0F0F6;
		border-radius: 5px;		
		overflow: hidden;
	}
	h4{
		background: #EEEEF4;
	    margin: 0;
	    height: 40px;
	    line-height: 40px;	
	    padding: 0 10px;	
	}
	.con{
		padding: 0 0 20px 10px;
	}
	.nav{
		float: left;
		margin: 10px 10px 0 0;
		color: deepskyblue;
	}
	.content{
		clear: both;
		padding-top: 10px;
	}
</style>