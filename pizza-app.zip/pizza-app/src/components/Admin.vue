<template>
	<div class="row admin">
		<div class="col-md-8">
			<NewPizza></NewPizza>
		</div>
		<div class="col-md-4">
			<h3>Menu:</h3>
			<div>
				<table class="table">
					<thead>
						<tr>
							<th>品种</th>
							<th>删除</th>
						</tr>
					</thead>
					<tbody v-for="v in dataPizza">
						<tr>
							<td>{{v.name}}</td>
							<td><button class="btn btn-sm" @click="deleteFood(v)">✖</button></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</template>

<script>
	import NewPizza from './NewPizza'
	import axios from "axios"
	export default({
		components:{
			"NewPizza":NewPizza
		},
		data(){
			return{
				//dataPizza:[]
			}			
		},
		computed:{
			/*从vuex中拿到数据*/
			dataPizza:{
				get(){
					//return this.$store.state.menuItems
					return this.$store.getters.getMenuItems
				},
				set(){
					
				}
			}
		},
		/*请求得到页面一加载需要展示的数据*/
		created(){
			axios.get('https://wd8113938945vvvdza.wilddogio.com/menu.json')
					.then(response => {
						let arr=[]
						var data=response.data
						for(var k in data){
							data[k].id=k
							//this.dataPizza.push(data[k])
							arr.push(data[k]);
						}

						/*更新vuex的数据，将有id的新数据传到vuex里*/
						this.$store.commit("getMenuItems",arr)
					})
					.catch(function(error){						
					    console.log(error);
			})
		},
		methods:{
			deleteFood(v){
				/*axios.delete('https://wd8113938945vvvdza.wilddogio.com/menu'+v.id+'/.json')
					.then(response => {
						console.log("++++++++++++++++");
						console.log(response);
						}
					)
					.catch(function(error){						
					    console.log(error);
			        })*/
			       
			    /*可能野狗接口有问题，接口成功了*/
			    fetch('https://wd8113938945vvvdza.wilddogio.com/menu'+v.id+'/.json',{
			    	methods:"DELETE",
			    	headers:{
			    		'Content-type':'application/json'
			    	}
			    })
			    .then(res =>res.json())
			    .then(data => {
			    	console.log(data);
			    	this.$router.push({name:"menuLink"})
			    })
			    .catch(err =>{})
			}
		}
	})
</script>

<style>
	.admin{
		padding-top: 30px;
	}
</style>