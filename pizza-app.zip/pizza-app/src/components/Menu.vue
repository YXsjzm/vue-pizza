<template>
     <div class="row">
     	<div class="col-md-8">
	        <table class="table table-hover">
	           <thead>
	             <tr>
	               <th>尺寸</th>
	               <th>价格</th>
	               <th>加入</th>
	             </tr>
	           </thead>
	           <tbody v-for="item in getItems" :key="item.name">
	           	 <tr>
	           	 	<td colspan="3" ><strong>{{item.name}}</strong></td>
	           	 </tr>
	           	 <tr v-for="option in item.option" :key="option.size">
	           	 	<td>{{option.size}}</td>
	           	 	<td>{{option.price}}</td>
	           	 	<td><div class="add" @click="addFood(item,option)">+</div></td>
	           	 </tr>
	           </tbody>
	        </table>     		
     	</div>
     	<div class="col-md-4">
     		<div v-if="baskets.length > 0">
     			<table class="table">    			
	     			<thead>
		             <tr>
		               <th>数量</th>
		               <th>品种</th>
		               <th>价格</th>
		             </tr>
		           </thead>
		           <tbody v-for="bsket in baskets" :key="bsket.mingcheng">	           	
		           	 <tr>
		           	 	<td>
		           	 		<span class="btn btn-sm" @click="decrease(bsket)">-</span>
		           	 		<span>{{bsket.count}}</span>
		           	 		<span class="btn btn-sm" @click="addCount(bsket)">+</span>
		           	 	</td>
		           	 	<td>{{bsket.name}}</td>
		           	 	<td>{{bsket.count*bsket.price}}</td>
		           	 </tr>
		           </tbody>
	     		</table>
	     		<div>总价格：{{totalPrice}}RMB</div>
	     		<button class="btn btn-success save">提交</button>
     		</div>
     		<div v-else="">购物车空空如也</div>
     		
     	</div>
     </div>
</template>

<script>
	export default({
		data(){
			return{
				//getItems:[],
				/*getItems:[
					{
						'name':'夏威夷披萨',
						'describe':'甜味',
						'option':[{
								'size':9,
								'price':36
						     },{
								'size':12,
								'price':46
						     },
						]
					},
					{
						'name':'江南披萨',
						'describe':'酸辣',
						'option':[{
								'size':9,
								'price':35
						     },{
								'size':12,
								'price':47
						     },
						]
					},
					{
						'name':'东北披萨',
						'describe':'苦味',
						'option':[{
								'size':9,
								'price':32
						     },{
								'size':12,
								'price':42
						     },
						]
					}
					
				],*/
				baskets:[],
			}
		},
		/*主要负责计算，只要this.baskets在变，界面显示值就在变*/
		computed:{
			/*获取vuex的中menuItems数据*/
			getItems(){
				//return this.$store.state.menuItems
				return this.$store.getters.getMenuItems
			},
			totalPrice(){
				let countAll=0
				for(var bsket in this.baskets){
					countAll+= this.baskets[bsket].price*this.baskets[bsket].count
				}
				return countAll
			}
			
		},
		created(){
			/*得到菜单的数据*/
			this.axios.get('https://wd8113938945vvvdza.wilddogio.com/menu.json')
					.then(response => {
						var data=response.data
						//this.getItems=data;
						/*调用vuex的方法，进行存值*/
						this.$store.commit("getMenuItems",data);
						
				
					})
					.catch(function(error){						
					    console.log(error);
			})
		},
		methods:{
			addFood:function(item,option){
				let newFood={
					mingcheng:item.name,
					name:item.name+option.size+"寸",
					price:option.price,
					count:1
				}
				if(this.baskets==0){
					this.baskets.push(newFood)
				}else{
					/*判断是否有重复的*/
					let sameFood=this.baskets.filter((bask) => {
						return bask.name==newFood.name&&bask.price==newFood.price
					})
					/*有重复的直接数量+1即可*/
					if(sameFood.length>0){
						sameFood[0].count++;
					}else{
						this.baskets.push(newFood)
					}
				}
				
			},
			/*购物车加1*/
			decrease:function(bsket){
				bsket.count--;
				if(bsket.count==0){
					this.removeBasket(bsket)
				}
			},
			/*购物车减一*/
			addCount:function(bsket){
				bsket.count++;
			},
			/*购物车数量为0时，清楚元素*/
			removeBasket:function(bsket){
				let i=this.baskets.indexOf(bsket)
				this.baskets.splice(i,1);
			}
		},
	})
</script>

<style>
	.add{
		width: 30px;
	    text-align: center;
	    border: 1px solid lightgrey;
	    color: darkgrey;
	}
	.add:hover{
		background: beige;
		cursor: pointer;
	}
	.btn-sm{
		background: none;
	}
	.save{
		width: 100%;
		margin-top: 10px;
	}
</style>