<template>
	<div class="home">
		<div class="conHome">
			<h1>欢迎大家品尝</h1>
			<h3>这里有你喜欢的pizza</h3>		
		    <el-button @click="getLongin" type="primary">let’s order</el-button>
		</div>
	</div>
	
</template>

<script>
	export default({
		methods: {
		    getLongin: function () {
		       //this.$router.go(-1)
		       //this.$router.push("/login")
		       this.$router.push({name:'menuLink'})
		    }
       },
  
	})
</script>

<style>
	.conHome{
		background:#EBEEF5 ;
		margin: 20px 10%;
		opacity: 0.8;
		padding: 30px 0;
	}
	.home{
		text-align: center;
		background-image: url(../common/img/logo1.jpg);
		padding: 100px;
		margin-bottom: 30px;
	}
</style>