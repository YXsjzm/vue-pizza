<template>
	<header class="header">
		<el-row :gutter="20">
		  <el-col :span="6">
		  	 <div class="navTitle grid-content bg-purple">
		  	 	<div class="logo">
		  	 		<i class="icon iconfont icon-huiyuan"></i>
		  	        <span>Pizza点餐系统</span>
		  	 	</div>  	 			  	 		  	    
		     </div>
		  </el-col>	
		  <el-col :span="12">
		    <el-menu default-active="1" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose">
		      <el-menu-item index="1" class="headNav">			      	
		      	<router-link tag="li" :to="{name:'homeLink'}">
		      		主页
		      	</router-link>			        
		      </el-menu-item>
		      <el-menu-item index="2" class="headNav">
		      	<router-link tag="li" :to="{name:'menuLink'}">
		      		菜单
		      	</router-link>			        
		      </el-menu-item>	
		      <el-menu-item index="3" class="headNav">
		      	<router-link tag="li" :to="{name:'adminLink'}">
		      		管理
		      	</router-link>			        
		      </el-menu-item>	
		      <el-menu-item index="4" class="headNav">
		      	<router-link tag="li" to="/about" >
		      		关于我们
		      	</router-link>			       
		      </el-menu-item>
		    </el-menu>
		  </el-col>
		  <el-col :span="6">
		  	<div class="optionTitle grid-content bg-purple">
		  		<ul>
		  			<li><router-link to="/login" class="navLink" v-show="!loginState">登陆</router-link></li>
		  			<li><router-link to="/register" class="navLink" v-show="!loginState">注册</router-link></li>
		  			<li>{{userName}}</li>
		  			<li><router-link to="/login" class="navLink" v-show="loginState">[退出]</router-link></li>
		  		</ul>
		  	</div>
		  </el-col>
		</el-row>
	</header>
</template>

<script>
	export default({
		/*data(){
			return{
				loginState:true
			}
		}*/
		computed:{
			/*从vuex中拿到登陆状态*/
			loginState(){
				return this.$store.getters.getLoginStates
			},
			userName(){
				return this.$store.getters.getUserName
			}
		},
	})
</script>

<style>
	 .logo{
	 	float: left;
	 }
	 ul li{
	 	list-style: none;
	 	float: left;
	 	padding: 0 5px;
	 }
	 header{
	 	background: #F7F8FD;
	 	line-height: 30px;
	 	height: 60px;
	 }
	 .logo i{
	 	color: blue;
	    font-size: 22px;
	    margin-left: 20px;
	 }
	 .logo span{
	 	font-size: 20px;
        font-weight: bold;
        margin-right: 10px;
	 }
	 .navLink{
	 	text-decoration: none;
	 }
	 .headNav{
	 	width: 25%;
	 }
	 .header .el-menu{
	 	border: none;
	 	background: none;
	 }
</style>