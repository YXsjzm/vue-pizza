<template>
	<div class="register">
		<!--阻止表单提交-->
		<form @submit.prevent="submitFunction">
		  <div class="form-group">
		  	<div class="pic">
		  		<i class="icon-icon iconfont icon-dongwu"></i>
		  	</div>
		    <label for="exampleInputEmail1">邮箱</label>
		    <input type="email" class="form-control" v-model="email" id="exampleInputEmail1" placeholder="Email">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputPassword1">密码</label>
		    <input type="password" class="form-control" v-model="password1" id="exampleInputPassword1" placeholder="Password">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputPassword1">再次确认密码</label>
		    <input type="password" class="form-control" v-model="conformPassword" id="exampleInputPassword1" placeholder="ConfirmPassword">
		  </div>
		  <button type="submit" class="btn btn-default">注册</button>
		</form>
	</div>
</template>

<script>
	
	import axios from "axios"
	export default({
		data(){
			return{
				email:"",
				password1:"",
				conformPassword:"",
			}			
		},
		methods: {
	        submitFunction: function(event) {	
	           let obj={
	           	  email:this.email,
	           	  password1:this.password1,
	           	  conformPassword:this.conformPassword
	           }
	           if(this.password1==this.conformPassword){
	           	   axios.post('https://wd8113938945vvvdza.wilddogio.com/users.json',obj)
					.then(response => this.$router.push({name:'loginLink'}))
					.catch(function(error){
					    console.log(error);
					});
	           }else{
	           	 alert("两次用户名密码不一致");
	           }
	        }
	   },
	})
</script>

<style>
	.register{
	    border: 1px solid #ced4da;
	    padding: 10px;
	}
	.btn-default{
		width: 100%;
	    background: #259B3C;
	    color: white;
	}
	.pic{
		text-align: center;		
        color: cornflowerblue;
	}
	.pic i{
		font-size: 140px;
	}
</style>