<template>
	<div>
		<form @submit.prevent="submitFunction">
			<h3>添加新的pizza</h3>
			<div>
				<label class="nameAdmin">品种</label>
				<input class="form-control" v-model="newPizza.name"/>
			</div>
			<div class="clear"></div>
			<div>
				<label class="nameAdmin">描述</label>
				<textarea cols="5" class="form-control" v-model="newPizza.describe"/>
			</div>
			<div class="clear"></div>
			<h5>选项1:</h5>
			<div>
				<label class="nameAdmin">尺寸</label>
				<input class="form-control" v-model="newPizza.size1"/>
			</div>
			<div class="clear"></div>
			<div>
				<label class="nameAdmin">价格</label>
				<input class="form-control" v-model="newPizza.price1"/>
			</div>
			<div class="clear"></div>
			<h5>选项2:</h5>
			<div>
				<label class="nameAdmin">尺寸</label>
				<input class="form-control" v-model="newPizza.size2"/>
			</div>
			<div class="clear"></div>
			<div>
				<label class="nameAdmin">价格</label>
				<input class="form-control" v-model="newPizza.price2"/>
			</div>
			<button class="btn btn-success" type="submit">提交</button>
		</form>
		
	</div>
</template>

<script>
	import axios from "axios"
	export default({
		data(){
			return{
				newPizza:{},
			}			
		},
		methods:{
			submitFunction:function(){
				let val={
						'name':this.newPizza.name,
						'describe':this.newPizza.describe,
						'option':[{
								'size':this.newPizza.size1,
								'price':this.newPizza.price2
						     },{
								'size':this.newPizza.size1,
								'price':this.newPizza.price2
						     },
						]
				};
				
				axios.post('https://wd8113938945vvvdza.wilddogio.com/menu.json',val)
					.then(response => {
						//this.$router.push({name:'menuLink'})
						/*添加新数据，执行vuex的添加方法，更改数据*/
						this.$store.commit("addNewPizza",val)
					})
					.catch(function(error){
					    console.log(error);
				})
			}
		}
		
	})
</script>

<style>
	.nameAdmin{
		float: left;
		width: 7%;
		line-height: 40px;
	}
	input,textarea{
		width: 93% !important;
		float: left !important;
	}
	.clear{
		clear:both
	}
	h5{
		margin-top: 20px;
	}
	h3{
		margin-bottom: 20px;
	}
	.btn-success{
		width: 100%;
		
	}
</style>