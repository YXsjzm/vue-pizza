<template>
	<div class="register">
		<!--阻止表单提交-->
		<form @submit.prevent="submitFunction">
		  <div class="form-group">
		  	<div class="pic">
		  		<i class="icon-icon iconfont icon-dongwu"></i>
		  	</div>
		    <label for="exampleInputEmail1">邮箱</label>
		    <input type="email" class="form-control" v-model="email" id="exampleInputEmail1" placeholder="Email">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputPassword1">密码</label>
		    <input type="password" class="form-control" v-model="password1" id="exampleInputPassword1" placeholder="Password">
		  </div>
		  <button type="submit" class="btn btn-default">登陆</button>
		</form>
	</div>
</template>

<script>
	import axios from "axios"
	export default({
		//进入组件前清空user
		beforeRouteEnter:(to,from,next)=>{
		/*使用vm才能调用到store的数据*/
		    next(vm => {
		    	vm.$store.commit("getUser",null);
		    });
		      
		},
		data(){
			return{
				email:"123@163.com",
				password1:"",
			}			
		},
		methods: {
	        submitFunction: function(event) {	
	        	
	            axios.get('https://wd8113938945vvvdza.wilddogio.com/users.json')
	            /*使用箭头函数才能拿到data的值*/
			    .then(response => {
			        let arr=[];
			        for(var key in response.data){
			        	arr.push(response.data[key]);
			        }
			        let count=arr.filter((k) => {
			        	return k.password1==this.password1&&this.email==k.email
			        })
			        if(count.length>0){
			        	/*把登陆的值存进去*/
			        	//this.$store.commit("getUser",count[0].email)
			        	
			        	/*登陆存值方法二*/
			        	this.$store.dispatch("setUser",count[0].email)
			        	
			        	this.$router.push({name:"homeLink"});
			        }else{
			        	alert("用户名或密码错误");
			        	//this.$store.commit("getUser",null)
			        	this.$store.dispatch("setUser",hull)
			        }
 			    })
			    .catch(function(error){
			        console.log(error)
			    });
	        }
	   },
	})
</script>

<style>
	.register{
	    border: 1px solid #ced4da;
	    padding: 10px;
	}
	.btn-default{
		width: 100%;
	    background: #259B3C;
	    color: white;
	}
	.pic{
		text-align: center;		
        color: cornflowerblue;
	}
	.pic i{
		font-size: 140px;
	}
</style>