import  'element-ui/lib/theme-chalk/index.css'
import Home from './components/Home'
import Menu from './components/Menu'
import Admin from './components/Admin'
import About from './components/about/About'
import Login from './components/Login'
import Register from './components/Register'
/*二级路由*/
import Contant from './components/about/Contant'
import History from './components/about/History'
import OrderGuide from './components/about/OrderGuide'
import ShopingInfor from './components/about/ShopingInfor'
/*三级路由*/
import Person from './components/about/contant/Person'
import Phone from './components/about/contant/Phone'

export const routes=[
    /*首页复用组件*/
   {path:"/",name:"homeLink",components:{
   	  default:Home,
   	  "history":History,
   	  "OrderGuide":OrderGuide,
   	  "shop":ShopingInfor
   }},
   {path:"/menu",name:"menuLink",component:Menu},
   {path:"/guanli",name:"adminLink",component:Admin,
	  /* beforeEnter:(to,from,next)=>{
	   	  alert("非登陆状态，不得进入");
	   	  next("/login");
	   }*/
   },
   {path:"/about",component:About,redirect:"/about/contant",children:[
      {path:"/about/history",name:"historyLink",component:History},
      {path:"/about/contant",name:"contantLink",redirect:"/phone",component:Contant,children:[
           {path:"/person",name:"personLink",component:Person},
           {path:"/phone",name:"phoneLink",component:Phone}
      ]},
      {path:"/about/orderGuide",name:"orderGuideLink",component:OrderGuide},
      {path:"/about/shopingInfor",name:"shopingInforLink",component:ShopingInfor}
   ]},
   {path:"/login",name:"loginLink",component:Login},
   {path:"/register",component:Register},
   {path:"*",redirect:"/"}
];