import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui'
import VueRouter from 'vue-router'
import $ from 'jquery' 
import 'bootstrap/dist/css/bootstrap.min.css'
/*import 'bootstrap/dist/js/bootstrap.min.js'
*/
import {routes} from './routes.js'
import axios from "axios"
import {store} from './store/store.js'

Vue.use(ElementUI); 
Vue.use(VueRouter); 
Vue.use($); 
/*基本路径暂不生效*/
axios.defaults.baseUrl="https://wd8113938945vvvdza.wilddogio.com/";

/*定义为全局，别的界面this.axios引用即可*/
Vue.prototype.axios=axios

const router= new VueRouter({
	routes,
	mode:"history",
	//页面滚动定位
	/*scrollBehavior(to, from, savedPosition) {
		  if (savedPosition) {
			  return savedPosition
			} else {
			  return { x: 0, y: 100 }
			}
	}*/
})

/*通过路由控制权限--全局守卫*/
/*router.beforeEach((to, from, next) => {
	if(to.path==="/login"||to.path==="/register"){
		next();
	}else{
		alert("请先登陆");
		next("/login");
	}
})*/
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
