<template>
  <div id="app">
     <Header></Header>
     <div class="container">
     	  <transition name="fade in">
             <router-view></router-view>
        </transition>  	 
	  </div>
	  <!--复用组件--name-->
	  <div class="container">
	  	 <el-row>
			  <el-col :span="8"><div class="grid-content bg-purple"></div>
			      <router-view name="OrderGuide"></router-view>
			  </el-col>
			  <el-col :span="8"><div class="grid-content bg-purple-light"></div>
			     <router-view name="history"></router-view>
			  </el-col>
			  <el-col :span="8"><div class="grid-content bg-purple"></div>
			     <router-view name="shop"></router-view>
			  </el-col>
			</el-row>
	  </div>
  </div>
  
</template>

<script>
	/*导入，注册，引用*/
import Header from './components/Header'
export default {
	components:{
		Header:Header
	}
}
</script>

<style>
body,html{
	margin: 0;
	padding: 0;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  padding: 0 10% 0 10%;
  min-width: 1000px;
}

</style>
