import Vue from 'vue'
import Vuex from 'vuex'
/*方法二将srore.js进行抽离*/
//import * as actions from './action'
//import * as getters from './getters'
//import * as mutations from './mutations'

/*方法三.使用Module进行模块化，根据属性建立文件*/
import menu from './module/menu.js';
import loginUser from './module/loginUser.js';
import longinState from './module/loginState.js';

Vue.use(Vuex)

export const store = new Vuex.Store({
	/*方法三.使用Module进行模块化，根据属性建立文件*/
	modules:{
		menu,
		loginUser,
		longinState
	}
	
	/*方法二将srore.js进行抽离*/
//	state: {
//		menuItems:{},
//		loginState:false,
//		userName:null
//	},
//	getters,
//	mutations,
//	actions,	


	/*方法一*/
//	state: {
//		menuItems:{},
//		loginState:false,
//		userName:null
//	},
//	getters: {
//		getMenuItems: state => state.menuItems,
//		getLoginStates:state => state.loginState,
//		getUserName:state => state.userName
//	},
//	mutations: {
//	   /*得到接口的初始数据*/
//	   getMenuItems(state,data){
//	   	  state.menuItems=data
//	   },
//	   /*添加新披萨*/
//	  addNewPizza(state,data){
//	  	state.menuItems.push(data);
//	  },
//	  getUser(state,user){
//	  	 if(user){
//	  	 	state.userName=user
//	  	 	state.loginState=true
//	  	 }else{
//	  	 	state.userName=null
//	  	 	state.loginState=false
//	  	 }
//	  }
//	  
//	},
//	actions: {
//		setUser({commit},user){
//			commit("getUser",user)
//		}
//	}
})