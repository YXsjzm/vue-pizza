	   /*得到接口的初始数据*/
export const getMenuItems = (state,data) => {
	   	  state.menuItems=data
	   }
	   /*添加新披萨*/
export const addNewPizza = (state,data) => {
	  	state.menuItems.push(data);
	  }
export const getUser = (state,user) => {
	  	 if(user){
	  	 	state.userName=user
	  	 	state.loginState=true
	  	 }else{
	  	 	state.userName=null
	  	 	state.loginState=false
	  	 }
	  }