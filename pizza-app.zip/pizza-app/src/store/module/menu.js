


const state= {
		menuItems:{},
	}
	
const getters= {
		getMenuItems: state => state.menuItems,
	}
const mutations= {
	  /*得到接口的初始数据*/
	   getMenuItems(state,data){
	   	  state.menuItems=data
	   },
	   /*添加新披萨*/
	  addNewPizza(state,data){
	  	state.menuItems.push(data);
	  },
	  
	}
export default{
	state,
	getters,
	mutations
}
