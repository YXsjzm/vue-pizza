

const state= {
		userName:null
	}
	
const getters= {
		getUserName:state => state.userName
	}
const mutations= {
	  getUser(state,user){
	  	 if(user){
	  	 	state.userName=user
	  	 	state.loginState=true
	  	 }else{
	  	 	state.userName=null
	  	 	state.loginState=false
	  	 }
	  }
	  
	}
const actions= {
		setUser({commit},user){
			commit("getUser",user)
		}
	}

export default{
	state,
	getters,
	mutations,
	actions
}