
export const getMenuItems=(state) => {
	return state.menuItems
}
export const getLoginStates=(state) => {
	return state.loginState
}
export const getUserName=(state) => {
	return state.userName
}
/*export const getUserName=(state) => state.userName*/