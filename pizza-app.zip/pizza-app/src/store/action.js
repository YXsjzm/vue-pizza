
export const setUser =({commit},user) =>{
		commit("getUser",user)
}
